from grade import *
keyList=['학번','학과','이름','성적']
valueList1=[]
valueList2=[]
valueList3=[]
valueList4=[]
valueList=[]
Student_dic=[]
j=1
aa=0
b=0
hak=[]
c=""

while True :
        
    print("%d번째 학생의 학번을 입력하시오:" % (j))
    valueList1.append(input())
    
    print("%d번째 학생의 학과을 입력하시오:" % (j))
    valueList2.append(input())
    
    print("%d번째 학생의 이름을 입력하시오:" % (j))
    valueList3.append(input())
    
    print("%d번째 학생의 성적을 입력하시오:" % (j))
    valueList4.append(input())
         
    j+=1
   
    a=input("추가하시겠습니까(a)? 끝내겠습니까(x)?")
    if a=='x':
        valueList.append(valueList1)
        valueList.append(valueList2)
        valueList.append(valueList3)
        valueList.append(valueList3)
                
        Student_dic=dict(zip(keyList,valueList))
        
        print("저장된 내용: %s:"% Student_dic)
        print("기술통계로 이동합니다")
        break
    
while True :
    aa=int(input("기술통계기능(0.프로그램 종료 1. 평균, 2. 순위(오름, 내림), 3. 최대/최소, 4. 학점) : "))   
    if aa==1:
        print("평균:%d점" % avg_data(valueList4))
    elif aa==2:
        c=input("정렬할 항목을 선택하시오")
        b=int(input("오름(0)과 내림(1)을 선택하시오"))
        if c=='학번':
            if b==1:
                print("학번 내림차순 정리 %s" % sort_data(valueList1,0))
            else :
                print("학번 오름차순 정리 %s" % sort_data(valueList1,1))
        elif c=='학과':
            if b==1:
                print("학번 내림차순 정리 %s" % sort_data(valueList2,0))
            else :
                print("학번 오름차순 정리 %s" % sort_data(valueList2,1))
        elif c=='이름':
            if b==1:
                print("이름 내림차순 정리 %s" % sort_data(valueList3,0))
            else :
                print("이름 오름차순 정리 %s" % sort_data(valueList3,1))
        elif c=='성적':
            if b==1:
                print("성적 내림차순 정리 %s" % sort_data(valueList4,0))
            else :
                print("성적 오름차순 정리 %s" % sort_data(valueList4,1))
        else :
            print("다시 입력해주세요")
            
    elif aa==3:
        b=int(input("점수의 최솟값(0)과 최댓값(1)을 선택하시오"))
        if b==1:
            print("최댓값:%d점" % minmax_data(valueList4,1))
        else :
            print("최솟값:%d점" % minmax_data(valueList4,0))   
    elif aa==4:
        hak=grading(valueList4)
        for i in range(0,len(valueList4)):
            print("학생:%s 학점:%s" % (valueList3[i],hak[i]))
    elif aa==0 :
        print("프로그램을 종료합니다")
        break
    else :
        print("다시 입력해주세요")

def avg_data(list1):
    sum=0
    count=0
    for i in list1 :
        sum+=int(i)
        count+=1
    return sum/count
def sort_data(list1,a):
    value=[]
    if a==1:
        value=sorted(list1)    
    else :
        value=sorted(list1)
        value.reverse()
    return value
    
def minmax_data(list1,a):
    list1=list(map(int,list1))
    value=list1[0]
    if a==1:
        for i in range(1,len(list1)):
           if list1[i]>value:
               value=list1[i]
    else:
        for i in range(1,len(list1)):
           if list1[i]<value:
               value=list1[i]
    return value

def grading(list1):
    list1=list(map(int,list1))
    value=[]
    for i in range(0,len(list1)):
        
        if list1[i]>=90 :
            value.append('A')
        elif 80<= list1[i]<=89:
            value.append('B')
        elif 70<=list1[i]<=79  :
            value.append('C')
        else :
            value.append('D')
    return value

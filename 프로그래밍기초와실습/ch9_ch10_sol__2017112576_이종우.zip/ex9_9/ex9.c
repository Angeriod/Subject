#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int factorial(int);
int main(void) {
	int n, nfact;
	printf("n���� �Է��Ͻÿ� : ");
	scanf("%d", &n);
	nfact = factorial(n);
	printf("\n%d-factorial=%d", n, nfact);
	return 0;
}
int factorial(int n) {
	int result;
	if (n == 1)
		return 1;
	else
		result = n * factorial(n - 1);
	return result;
}
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int sum(int n)
{
	if (n == 0 )
		return 0;
	else
		return n + sum(n-1) ;
}
main()
{
	int x, result;
	printf(" ������ �Է�!\n");
	scanf("%d", &x);
	result = sum(x);
	printf(" ���: %d\n", result);
}
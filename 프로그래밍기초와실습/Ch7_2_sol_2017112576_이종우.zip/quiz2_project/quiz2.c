#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int a,b;

	for (a = 1; a < 9; a++)
	{
		if (a == 1)
		continue;

		for (b = 1; b < a; b++)
			printf("%d", b);

		for (b = 1; b < 9 - a; b++)
		
			printf("*");
			
		
		printf("\n");

		
	}

	return 0;
	

}
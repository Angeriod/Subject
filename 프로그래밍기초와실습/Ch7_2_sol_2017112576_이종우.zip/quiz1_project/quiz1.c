#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int i, j,sum=0;

	for (i = 10; i < 31; i++)
		for (j = 0; j < 6; j++)
			sum += i * j;
    
	printf("%d\n", sum);
	return 0;
			
}
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int a, b;

	for (a = 2; a <= 9; a++)
		for (b = 1; b <= 9; b++)
			printf("%d X %d = %d\n", a, b, a * b);
	

	return 0;


}
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int a, b;

	for (a = 2; a <= 9; a++)
	{
		if (a == 8)
			break;
		if (a % 2 == 0)
				continue;

		for (b = 1; b <= 9; b++)
		{
			printf("%d X %d = %d\n", a, b, a * b);
			if (b % 3==0)//if(!(b%3)) ���� �ƴϸ�
				printf("\n");
		}
	}
	return 0;


}
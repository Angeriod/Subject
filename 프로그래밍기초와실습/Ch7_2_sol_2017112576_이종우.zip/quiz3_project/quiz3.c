#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int num,a, b;

	printf("���:");
	scanf("%d", &num);
	for (a = 0; a < num; a++)
	{
		for (b = 1; b < num - a; b++)

			printf(" ");
		for (b = 1; b <= 2*a+1; b++)
			printf("*");

	
		printf("\n");


	}

	return 0;


}
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
    int i, n;
    int sum = 0;
    for (;;)
    {
        printf("�ڿ��� n���� �Է��Ͻÿ�. n�� 0�̸� �����Ͻÿ�!  ");
        scanf("%d", &n);
        sum = 0;
        for (i = 1; i <= n; i++)
        {
            if (i % 2 == 0) // ¦���� ���� 
            {
                sum -= i;
                printf("-%d", i);
            }
            else // Ȧ���� ���ϰ� 
            {
                sum += i;
                if (i == 1)
                {
                    printf("%d", i);
                    continue;
                }
                printf("+%d", i);
            }
        }
        
        if (n == 0)
            break;

        printf("=%d\n", sum);
        
    }


    return 0;
}

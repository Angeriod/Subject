#include <stdio.h>
#define MAX 100
#define LINEITEM 10
int main(void) 
{
	int count = 1, i;

	for (i = 1; i < MAX; i++)
	{

		if (i % 3 != 0 && i % 5 != 0 && i % 7 != 0)
		{
			printf("%3d", i);
			if (count % LINEITEM == 0)
			{
				printf("\n");
			}
			count++;
		}

	}

	return 0;


}
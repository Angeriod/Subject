#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int count = 1;
void roll_dice();
int main()
{
	srand(time(NULL));
	roll_dice();
}
void roll_dice()
{
	
	static int a, b, c, d, e, f ;
	int random;
	printf("��ȸ  1��  2��  3��  4��  5��  6��\n");
	for (count; count < 21; count++)
	{
		random = (rand() % 6) + 1;
		if (random == 1)
			a++;
		else if (random == 2)
			b++;
		else if (random == 3)
			c++;
		else if (random == 4)
			d++;
		else if (random == 5)
			e++;
		else if (random == 6)
			f++;
		else
			continue;

		
		printf("%2dȸ    %d    %d    %d    %d    %d    %d\n",count, a, b, c, d, e, f);
		
	}
}
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAX 45
int generate_random_number(int max);
int main(void) {
	int n1=0, n2=0, n3=0, n4=0, n5=0, n6= 0;
	srand((unsigned) time(NULL));
	n1 = generate_random_number(n1);
	do { n2 = generate_random_number(n2); } while (!(n1!=n2) );
	do { n3 = generate_random_number(n3); } while (!(n1 != n3 && n2 != n3));
	do { n4 = generate_random_number(n4); } while (!(n1 != n4 && n2 != n4 && n3 != n4));
	do { n5 = generate_random_number(n5); } while (!(n1 != n5 && n2 != n5 && n3 != n5 && n4 != n5));
	do { n6 = generate_random_number(n6); } while (!(n1 != n6 && n2 != n6 && n3 != n6 && n4 != n6 && n5 != n6));
	printf("�ζ� ��÷��ȣ�� %d, %d, %d, %d, %d, %d �Դϴ�. \n", n1, n2, n3, n4, n5, n6);
	return 0;
}
int generate_random_number(int max) {
	return rand() % MAX+1 ;
}
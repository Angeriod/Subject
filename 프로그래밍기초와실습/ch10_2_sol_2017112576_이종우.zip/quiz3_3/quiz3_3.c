#include <stdio.h>
void main(void)
{
    int i;
    int in[10] = { 7, 2, 9, 0, 1, 4, 6, 8, 3, 5 };
    int minpos = 0;
    int temp;
    //���� �迭 ���
    printf("Before: ");
    for (i = 0; i < 10; i++)
        printf("%2d ", in[i]);
    printf("\n");
    for(int r=0;r<9;r++)
    { 
     //�ּ� ��ġ ã��
        for (i = r; i<10; i++)
        {
            if (in[i] < in[minpos])
                minpos = i;
        }
        //��ȯ�ϱ�
        temp = in[r];
        in[r] = in[minpos];
        in[minpos] = temp;
    }
    //��� ���
    printf("After : ");
    for (i = 0; i < 10; i++)
        printf("%2d ", in[i]);
}
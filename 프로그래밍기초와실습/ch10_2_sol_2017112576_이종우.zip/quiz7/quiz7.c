#include <stdio.h> 
int main(void)
{
    int i, j, n = 0;
    int a[4][4], b[4][4];
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            a[i][j] = ++n;
            b[i][j] = 0;
        }
    }
    for (i = 0; i < 4; i++)               //b�� �迭 �� ����
    {
        for (j = 0; j < 4; j++)
        {
            b[4 - 1 - j][i] = a[i][j];
        }
    }
    printf("A=\n");
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            printf("%3d", a[i][j]);       if (j == 3) printf("\n");
        }
    }
    printf("B=\n");
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            printf("%3d", b[i][j]);       if (j == 3) printf("\n");
        }
    }
    return 0;
}
#include <stdio.h>
void main(void)
{
	int i;
	//�迭�� ����� �ʱ�ȭ
	int in[10] = { 7, 2, 9, 0, 1, 4, 6, 8, 3, 5 };
	//�迭�� Ȱ��
	printf("Before: ");
	for (i = 0; i < 10; i++)
		printf("%2d ", in[i]);
	printf("\n");
	printf("After : ");
	for (int k = 9; k >= 0; k--)
		printf("%2d ", in[k]);
	printf("\n");
}
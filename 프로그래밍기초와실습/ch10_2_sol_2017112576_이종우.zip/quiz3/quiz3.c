#include <stdio.h>
void main(void)
{
	int i;
	int in[10] = { 7, 2, 9, 0, 1, 4, 6, 8, 3, 5 };
	int min;
	printf("Array: ");
	for (i = 0; i < 10; i++)
		printf("%2d ", in[i]);
	printf("\n");
	min = in[0];
	for (i = 0; i < 10; i++)
	{
		if (in[i]<min)
			min = in[i];
	}
	printf("�ּҰ� : %d \n", min);
}
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
main()
{
    int x, y, i, result = 0;
    printf("2�� ������ �Է�!\n");
    scanf("%d %d", &x, &y);

    for (i = y; i > 0; i--)
    {
        result += x;
    }
    printf("%d\n", result);
}
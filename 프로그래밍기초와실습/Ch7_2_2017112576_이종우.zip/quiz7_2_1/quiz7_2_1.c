#include<stdio.h>
int main()
{
	for (int y = 0; y < 7; y++)
	{
		for (int x = 0; x < (6 - y); x++)
			printf(" ");

		for (int c = 6 ; c >=6-y ; c--)
			printf("*");
		printf("\n");

	}

	return 0;		
}
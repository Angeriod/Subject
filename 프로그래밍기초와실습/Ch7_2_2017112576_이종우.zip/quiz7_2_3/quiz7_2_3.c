#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main(void)
{
    int  i, j, n;
    printf("1~9������ ���� �Է��Ͻÿ�? ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = n; j > 0; j--)
        {
            if (j == 1 || j == n || i == 1 || i == n)
                printf("%d",j);
            else
                printf(" ");
        }
        printf("\n");
    }

    printf("\n");
    return 0;
}
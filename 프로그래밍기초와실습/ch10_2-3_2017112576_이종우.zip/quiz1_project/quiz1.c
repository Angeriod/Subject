#include<stdio.h>
void transpose(int a[][3], int b[][3], int n);
void print(int a[][3], int n);
int main(void)
{
	int r, c;
	int A[3][3] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
	int B[3][3];
	rintf("A=\n");
	print(A, 3);
	transpose(A, B, 3);
	printf("B=\n");
	print(B, 3);
	return 0;
}
void transpose(int a[][3], int result[][3], int n)
{
	for (int r = 0; r < n; r++)
		for (int c = 0; c < n; c++)
			result[r][c] = a[c][r];
}
void print(int a[][3], int n) 
{
	for (int r = 0; r < n; r++)
	{
		for (int c = 0; c < n; c++)
			printf("%d ", a[r][c]);
		printf("\n");
	}
}
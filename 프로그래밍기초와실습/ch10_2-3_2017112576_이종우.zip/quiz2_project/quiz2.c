#include <stdio.h>
void mul(int a[][3], int b[][3], int c[][3], int n);
void print(int a[][3], int n);
int main(void) {
	int r, c, k;
	int A[3][3] = { { 2, 1, 0 }, { 1, 2, 1 }, { 0, 1, 2 } };
	int B[3][3] = { { 1, 0, 0 }, { 0, 0, 1 }, { 0, 1, 0 } };
	int C[3][3];
	mul(A, B, C, 3);
	printf("C=\n");
	print(C, 3);
	return 0;
}
void mul(int A[][3], int B[][3], int C[][3], int n)
{
	for (int r = 0; r < n; r++) {
		for (int c = 0; c < 3; c++) {
			int sum = 0;
			for (int k = 0; k < 3; k++)
			{
				sum += A[r][k] * B[k][c];
				C[r][c] = sum;
			}
		}
	}


}
void print(int a[][3], int n)
{
	for (int r = 0; r < n; r++) {
		for (int c = 0; c < n; c++) printf("%d ", a[r][c]);
		printf("\n");
	}
}